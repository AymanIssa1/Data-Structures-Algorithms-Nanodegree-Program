I am using an approach almost similar to binary search
The expected time complexity is O(log(n)) and space complexity is O(1)

Note: I don't use recursion... it's just in place search with 3 pointers so the time complexity suppose to be O(1)