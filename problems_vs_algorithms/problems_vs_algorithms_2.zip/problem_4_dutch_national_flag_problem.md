it just compare from the front and back of the array and swap elements if needed
the time complexity if O(n) and space complexity is O(1)