Travserse throght the array 1 and compare values and assign it to min and max 
The expected time complexity is O(n) and space complexity is O(1)