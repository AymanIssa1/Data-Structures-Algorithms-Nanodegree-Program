I am using an approach almost similar to binary search
The expected time complexity is O(log(n)) and space complexity is O(1)