I have used Trie structure to store strings characters and I  am using Trie class to solve this problem.

TrieNode insert method has time complexity and space complexity of O(1) .
TrieNode suffixes method has time complexity and space complexity of O(n) .

Trie insert method has time complexity and space complexity of O(n) .
Trie find method has time complexity of O(n) and space complexity of O(1).