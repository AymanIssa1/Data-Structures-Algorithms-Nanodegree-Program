I have used merge sort to re-arrange the array from greater to smaller because it has time complexity of O(log(n) and space complexity of O(n))
and traversed once over the sorted array.

So over all time complexity is O(nlog(n))