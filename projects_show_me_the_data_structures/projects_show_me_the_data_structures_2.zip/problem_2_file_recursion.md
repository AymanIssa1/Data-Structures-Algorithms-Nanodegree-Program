I have used recursive approach to solve this issue 
which take the suffix and path and going deep recursively 
till it find the required files.

space and time complexity are O(d) where d = depth