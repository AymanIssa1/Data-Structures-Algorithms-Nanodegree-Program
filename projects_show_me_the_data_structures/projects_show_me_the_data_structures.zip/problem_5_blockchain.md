I have used Linked List data structure to make a chain of blocks so I can traverse between them easily and find the required item

Time complexity is O(1) 
Space complexity are O(n) where n = number of nodes