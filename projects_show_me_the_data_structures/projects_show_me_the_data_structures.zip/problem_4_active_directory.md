I have used recursive approach to solve this issue 
which take the user and the group 
and it goes deep into the groups till it find the required user
and it takes o(d) of stack space where d is depth of recursion functions

time and space complexity are O(n) where n = nodes