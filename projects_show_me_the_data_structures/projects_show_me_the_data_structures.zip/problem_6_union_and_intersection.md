i have used dict data structure to find the intersected or union items between them

Time complexity and Space complexity are O(n + m) 
where n = number of nodes in first linked list
where m = number of nodes in second linked list