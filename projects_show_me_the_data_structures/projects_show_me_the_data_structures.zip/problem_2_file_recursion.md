I have used recursive approach to solve this issue 
which take the suffix and path and going deep recursively 
till it find the required files and it takes o(d) of stack space where d is depth of recursion functions

space and time complexity are O(d) where d = depth