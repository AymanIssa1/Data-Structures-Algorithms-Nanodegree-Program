I have used directory to count frequnces then I have used heapq to priortize the elements from lowest frequency to highest one. 
after that i was popping 2 nodes from the queue (list) then merge them into small tree till i created huffman tree.
afterwords I created huffman codes table by traversing through the tree.

after that I created the encoded codes.

and for decoding I just traversed again into the tree using 0s and 1s till i reached a leap so i can decode the data