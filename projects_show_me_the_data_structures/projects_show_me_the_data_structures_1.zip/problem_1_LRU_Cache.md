According to this assignment, “Least Recently Used (LRU) cache.
I used dictionary data structure with counter to determine how many times each item has been accessed 
and if we reached the capacity it started to remove the least used item and remove it and insert the new one instead.

Performance is O(1) for getting an item, O(n) for inserting an item and space complexity is O(n) the size of the Cache. 