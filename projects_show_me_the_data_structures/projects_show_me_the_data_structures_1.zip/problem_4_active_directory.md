I have used recursive approach to solve this issue 
which take the user and the group 
and it goes deep into the groups till it find the required user

space and time complexity are O(d) where d = depth